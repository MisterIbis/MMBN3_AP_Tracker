# Megaman Battle Network 3 Tracker Package for PopTracker

BN3 Item and Map Tracker for PopTracker.

PopTracker can be found [here](https://github.com/black-sliver/PopTracker/releases).


## Installation

Just download the lastest build and put in your packs folder (as a zip or unpacked, both work).

### PopTracker

For PopTracker the packs folder can be under `USER/Documents/PopTracker/packs`, `USER/PopTracker/packs` or `APP/packs`, where `USER` stands for your user directory and `APP` for the PopTracker installation directory.

## Customization

### PopTracker

For Customization in PopTracker just edit the pack's files. Documenation for PopTracker's pack format can be found [here](https://github.com/black-sliver/PopTracker/blob/master/doc/PACKS.md).
For example: if you want to change the broadcast layout, you can add your desired layout to the `layout/broadcast.json` file.
Make sure you have you layout backed up, so you don't lose it when you override the file while updating the pack.

## Credits

Maps by Megaboy and MisterIbis
